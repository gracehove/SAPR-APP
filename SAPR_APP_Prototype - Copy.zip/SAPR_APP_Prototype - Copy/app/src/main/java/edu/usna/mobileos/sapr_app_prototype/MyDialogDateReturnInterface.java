package edu.usna.mobileos.sapr_app_prototype;

import java.util.Date;

public interface MyDialogDateReturnInterface {

    public void onDialogDateClick(Date date, long difference);

}
