package edu.usna.mobileos.sapr_app_prototype;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class myDatePickerDialog extends DialogFragment implements android.app.DatePickerDialog.OnDateSetListener{

    MyDialogDateReturnInterface myInterface;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogDateReturnInterface) getActivity();

        Calendar c = Calendar.getInstance(); //current date and time

        android.app.DatePickerDialog dateDlg = new android.app.DatePickerDialog(getActivity(), this,
                c.get(Calendar.YEAR),  //set default year
                c.get(Calendar.MONTH), //set default month
                c.get(Calendar.DAY_OF_MONTH)); //set default day

        return dateDlg;
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
        Log.d("IT472", "Date Selected: " + (monthOfYear + 1) + "/" + dayOfMonth + "/" + year);

        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
        Calendar cal = new GregorianCalendar(year, monthOfYear, dayOfMonth);

        //YOU NEED TO GO IN AND MAKE SURE THIS DATE RETURNS!!

        Date today = new Date();

        GregorianCalendar selectedDateCal = new GregorianCalendar(year, monthOfYear, dayOfMonth);


        Date selectedDate = selectedDateCal.getTime();
        long difference = selectedDate.getTime() - today.getTime();

        myInterface.onDialogDateClick(selectedDate, difference);
    }
}
