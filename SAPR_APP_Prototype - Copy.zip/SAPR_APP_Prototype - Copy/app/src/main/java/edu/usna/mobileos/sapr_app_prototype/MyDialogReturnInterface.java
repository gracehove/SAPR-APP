package edu.usna.mobileos.sapr_app_prototype;

import java.util.HashMap;

public interface MyDialogReturnInterface {

    public void onDialogItemClick(HashMap<String, String> contact);

}
