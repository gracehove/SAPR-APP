package edu.usna.mobileos.sapr_app_prototype;

import java.util.Date;

public interface MyDialogTimeReturnInterface {

    public void onDialogTimeClick(int hour, int minute);

}
