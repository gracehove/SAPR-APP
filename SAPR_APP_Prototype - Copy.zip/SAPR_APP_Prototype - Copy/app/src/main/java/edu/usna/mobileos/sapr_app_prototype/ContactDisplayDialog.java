package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

public class ContactDisplayDialog extends DialogFragment implements DialogInterface.OnClickListener{

    MyDialogSimpleReturnInterface myInterface; //custom listener is a class member

    EditText name;
    EditText number;
    String contactName;
    String contactNumber;


    public ContactDisplayDialog(String contactName, String contactNumber){
        this.contactName = contactName;
        this.contactNumber = contactNumber;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogSimpleReturnInterface) getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View layout = inflater.inflate(R.layout.contact_display, null);
        name = layout.findViewById(R.id.name);
        number = layout.findViewById(R.id.number);
        builder.setView(layout);

        //Update contact information displayed
        name.setText(contactName);
        number.setText(contactNumber);

        builder.setTitle("SETTINGS")
                .setMessage("Contact Information")
                .setPositiveButton("UPDATE", this)
                .setNegativeButton("DELETE", this)
                .setNeutralButton("CANCEL", this)
                .setCancelable(false);


        //call create to build the dialog and return it
        return builder.create();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int id) {

        String buttonName = "";
        switch (id) {
            case Dialog.BUTTON_NEGATIVE:
                buttonName = contactName;
                break;
            case Dialog.BUTTON_POSITIVE:
                String newContactName = String.valueOf(name.getText());
                contactNumber = String.valueOf(number.getText());
                buttonName = contactName + "UPDATE" + newContactName + "UPDATE" + contactNumber;
                break;
            case Dialog.BUTTON_NEUTRAL:
                buttonName = "Neutral";
        }

        myInterface.onDialogSimpleItemClick(buttonName);
    }
}
