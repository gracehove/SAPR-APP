package edu.usna.mobileos.sapr_app_prototype;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.ContextThemeWrapper;
import android.widget.Toast;

import java.sql.Time;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // do something here
        //for example, could start a service using

        String senderName = intent.getStringExtra("sender");
        String messageContent = intent.getStringExtra("message");
        String typeContent = intent.getStringExtra("type");

        //SEND MESSAGE
        Toast.makeText(context, messageContent, Toast.LENGTH_LONG).show();

        String fullMessage = "Hey this is " + senderName + ", " + messageContent;

        //create implicit intent for ACTION_SENDTO
        Intent intent2 = new Intent(Intent.ACTION_SENDTO);
        //set the number and message
        intent2.setData(Uri.parse("smsto:5554")); //5556 is the "phone number" of the second AVD
        intent2.putExtra("sms_body", fullMessage);
        //start activity for intent: this will start the default messaging app
        context.startActivity(intent2);
        //context.startService(new Intent(context, MyAlarmService.class));

    }
}