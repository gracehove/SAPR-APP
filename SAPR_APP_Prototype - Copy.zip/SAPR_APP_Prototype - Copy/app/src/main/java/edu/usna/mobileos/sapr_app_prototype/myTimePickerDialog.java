package edu.usna.mobileos.sapr_app_prototype;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.TimePicker;

import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class myTimePickerDialog extends DialogFragment implements android.app.TimePickerDialog.OnTimeSetListener {

    MyDialogTimeReturnInterface myInterface;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogTimeReturnInterface) getActivity();

        Calendar c = Calendar.getInstance(); //current date and time

        android.app.TimePickerDialog timeDlg = new android.app.TimePickerDialog(getActivity(), this,
                c.get(Calendar.HOUR_OF_DAY), //default hour
                c.get(Calendar.MINUTE),  //default minute
                true);  //is24Hour

        return timeDlg;
    }

    //hour is a 24 hour format
    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        //The method onTimeSet is called once even if the back key is pressed,
        // and is called twice if ‘Done’ is selected.  This is a known issue!



        Log.d("IT472", "Time Selected: " + hourOfDay + ":" + minute);

        myInterface.onDialogTimeClick(hourOfDay,minute);
    }
}
