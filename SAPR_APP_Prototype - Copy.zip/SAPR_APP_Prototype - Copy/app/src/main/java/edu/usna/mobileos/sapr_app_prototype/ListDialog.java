package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

public class ListDialog extends DialogFragment implements DialogInterface.OnClickListener{

    MyDialogSimpleReturnInterface myInterface;
    String[] choice;

    public ListDialog(String[] choice) {
        this.choice = choice;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogSimpleReturnInterface) getActivity();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("List Dialog: Select One")
                .setTitle("Select Friend to Contact:")
                .setNegativeButton("CANCEL", this)
                .setCancelable(true)
                .setItems(choice, this); // set list here and set a listener
        //no need to set buttons, because the dialog is dismissed
        // when you select an element in the list

        //create the dialog based on the parameters set in the builder
        return builder.create();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int itemId) {
        String item = "";
        switch (itemId) {
            case Dialog.BUTTON_NEGATIVE:
                item = "Negative";
                myInterface.onDialogSimpleItemClick(item);
                break;
            default:
                item = choice[itemId];
                myInterface.onDialogSimpleItemClick(item);
                break;
        }
    }
}
