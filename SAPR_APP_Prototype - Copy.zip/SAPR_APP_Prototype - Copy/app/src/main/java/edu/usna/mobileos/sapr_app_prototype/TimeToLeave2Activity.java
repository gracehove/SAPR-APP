package edu.usna.mobileos.sapr_app_prototype;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class TimeToLeave2Activity extends AppCompatActivity implements MyDialogDateReturnInterface, MyDialogTimeReturnInterface{

    private AlarmManager alarmManager;

    public TextView sender;
    public TextView type;
    public TextView message;

    public long timeDateDelay;

    Intent intent;

    private String senderName;
    private String messageContent;
    private String typeContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_to_leave2);

        sender = findViewById(R.id.sender);
        type = findViewById(R.id.type);
        message = findViewById(R.id.message);

        intent = getIntent();

        senderName = intent.getStringExtra("sender");
        messageContent = intent.getStringExtra("message");
        typeContent = intent.getStringExtra("type");

        sender.setText(senderName);
        message.setText(messageContent);
        type.setText(typeContent);

        //initialize Alarm Manager
        alarmManager = (AlarmManager) getBaseContext()
                .getSystemService(Context.ALARM_SERVICE);
    }

    public void returnToSettings(View view) {
        Intent intent = new Intent(getBaseContext(), TimeToLeaveActivity.class);
        startActivity(intent);
        finish();
    }

    public void sendMessage(View view) {
        String fullMessage = "Hey this is " + senderName + ", " + messageContent;

        //create implicit intent for ACTION_SENDTO
        Intent intent2 = new Intent(Intent.ACTION_SENDTO);
        //set the number and message
        intent2.setData(Uri.parse("smsto:5554")); //5556 is the "phone number" of the second AVD
        intent2.putExtra("sms_body", fullMessage);
        //start activity for intent: this will start the default messaging app
        startActivity(intent2);
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle item selection
        switch(item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent2 = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void ScheduleSendMessage(View view) {
        //Launch timer dialog

        //TIME SECOND
        myTimePickerDialog dialog7 = new myTimePickerDialog();
        dialog7.show(getSupportFragmentManager(), "TimePickerDialog");

        //DATE FIRST
        myDatePickerDialog dialog6 = new myDatePickerDialog();
        dialog6.show(getSupportFragmentManager(), "DatePickerDialog");

    }

    @Override
    public void onDialogDateClick(Date date, long difference) {
        //The difference is the seconds until the selected day starts.. or seconds until MIDNIGHT

        //If the difference is negative, the selected day is today
        if (difference <= 0){
            timeDateDelay = 0;
        }
        else
            timeDateDelay = difference;

        //Trouble shooting initiative
        String differences = String.valueOf(difference);
        Toast.makeText(getBaseContext(), differences, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDialogTimeClick(int hour, int minute) {
        //YOU GOT THE TIME BISH

        long totalSeconds = (hour * 60 * 60) + (minute * 60);

        //Date today = new Date();
        //long currentTime = today.getTime();

        //String differences = String.valueOf(currentTime);
        //Toast.makeText(getBaseContext(), differences, Toast.LENGTH_LONG).show();

        //long timeUntilSelected = totalSeconds - currentTime + timeDateDelay;

        //Now the temporary solution is..
        //Sleep until the specified time.

        String fullMessage = "Hey this is " + senderName + ", " + messageContent;

        //create implicit intent for ACTION_SENDTO
        final Intent intent2 = new Intent(Intent.ACTION_SENDTO);
        //set the number and message
        intent2.setData(Uri.parse("smsto:5554")); //5556 is the "phone number" of the second AVD
        intent2.putExtra("sms_body", fullMessage);

        //Intent handler required to ensure 7 second delay.
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent2);
            }
        }, 30000); //variable second delay
    }

}
