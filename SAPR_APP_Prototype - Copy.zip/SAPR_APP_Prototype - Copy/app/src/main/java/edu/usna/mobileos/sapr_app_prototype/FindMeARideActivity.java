package edu.usna.mobileos.sapr_app_prototype;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class FindMeARideActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Location currentLocation;
    TextView tv;
    SupportMapFragment supportMapFragment;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_me_a_ride);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        //SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
        //        .findFragmentById(R.id.map);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLocation();
        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        //supportMapFragment.getMapAsync(this);


        tv = (TextView)findViewById(R.id.text_view_id);
        final TextView tv_error = (TextView)findViewById(R.id.error_message);


        Button send_location = (Button) findViewById(R.id.button_id);

        send_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendLocation(v);
            }
        });

        Button call_shipmate = (Button) findViewById(R.id.button_id2);

        call_shipmate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callShipmate(v);
            }
        });

        final Button call_a_friend = (Button) findViewById(R.id.button_id3);

        call_a_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callFriend(v);
            }
        });

        Button call_a_taxi = (Button) findViewById(R.id.button_id4);

        call_a_taxi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callTaxi(v);
            }
        });

        ToggleButton toggle = (ToggleButton) findViewById(R.id.locationToggle);
        final Button redirect_button = (Button) findViewById(R.id.settings_redirect);

        redirect_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
            }
        });
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    tv_error.setText("ERROR! Location Services are not enabled. Please enable them in Settings.");
                    redirect_button.setVisibility(View.VISIBLE);

                } else {
                    // The toggle is disabled
                    tv_error.setText("");
                    redirect_button.setVisibility(View.GONE);
                }
            }
        });
        ToggleButton toggle2 = (ToggleButton) findViewById(R.id.savedContactsToggle);
        toggle2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    call_a_friend.setVisibility(View.GONE);
                } else {
                    // The toggle is disabled
                    call_a_friend.setVisibility(View.VISIBLE);
                }
            }
        });
    }


    private void callFriend(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose a Friend");
        String[] animals = {"Friend One", "Friend Two", "Friend Three"};
        builder.setItems(animals, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: open_call(this, "tel:+1111111111");
                    case 1: open_call(this, "tel:+2222222222");
                    case 2: open_call(this, "tel:+3333333333");
                }
            }
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void open_call(DialogInterface.OnClickListener view, String num){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse(num));
        startActivity(intent);
    }

    private void open_text(DialogInterface.OnClickListener view, String num){
        try{
            SmsManager smgr = SmsManager.getDefault();
            smgr.sendTextMessage(num,null,"I need help, I am currently located at: " + currentLocation.getLatitude() + "" + currentLocation.getLongitude(),null,null);
            Toast.makeText(FindMeARideActivity.this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            Toast.makeText(FindMeARideActivity.this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
        }
    }

    private void callShipmate(View view){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:+4439951400"));
        startActivity(intent);
    }

    private void callTaxi(View view){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:+4103205961"));
        startActivity(intent);
    }

    private void sendLocation(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose a Friend");
        String[] animals = {"Friend One", "Friend Two", "Friend Three"};
        builder.setItems(animals, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: open_text(this, "1111111111");
                    case 1: open_text(this, "2222222222");
                    case 2: open_text(this, "3333333333");
                }
            }
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    tv.setText("Current Location: " + currentLocation.getLatitude() + "" + currentLocation.getLongitude());
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(FindMeARideActivity.this);
                }
            }
        });
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng loc = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        //LatLng loc = new LatLng(38.978774, -76.484496);
        mMap.addMarker(new MarkerOptions().position(loc).title("You are here"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, 16));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }
}