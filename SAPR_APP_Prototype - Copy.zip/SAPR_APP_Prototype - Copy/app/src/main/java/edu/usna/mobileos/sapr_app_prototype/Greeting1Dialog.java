package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ToggleButton;

import androidx.fragment.app.DialogFragment;

import java.util.HashMap;

public class Greeting1Dialog extends DialogFragment implements DialogInterface.OnClickListener {

    MyDialogReturnInterface myInterface; //custom listener is a class member

    EditText name;
    EditText number;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogReturnInterface) getActivity();
        //create an alert dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View layout = inflater.inflate(R.layout.contact_dialog, null);
        name = layout.findViewById(R.id.name);
        number = layout.findViewById(R.id.number);

        builder.setView(layout);

        builder.setTitle("WELCOME")
                .setMessage("Please enter your information:")
                .setPositiveButton("NEXT", this)
                .setCancelable(false);


        //call create to build the dialog and return it
        return builder.create();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int id) {

        HashMap<String, String> contact = new HashMap<String, String>();
        //id identifies the button clicked

        if (id == Dialog.BUTTON_POSITIVE){
            String contactName = String.valueOf(name.getText());
            String phoneNumber = String.valueOf(number.getText());
            contact.put(contactName, phoneNumber);
        }

        myInterface.onDialogItemClick(contact);
    }
}
