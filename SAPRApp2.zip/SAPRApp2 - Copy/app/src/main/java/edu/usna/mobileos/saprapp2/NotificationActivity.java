package edu.usna.mobileos.saprapp2;

class NotificationActivity {
}
