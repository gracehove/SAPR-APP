package edu.usna.mobileos.saprapp2;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
//import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.util.ArrayList;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

//mport com.google.firebase.database.IgnoreExtraProperties;

public class ContactSelection extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener {

    private ListView contactsList;
    private String[] contactsArray;
    private ArrayAdapter contactsAdapter;
    private Button sendAlertButton;
    private EditText et;
    private Button sendTextButton;
    private EditText sendTextEdit;

    private SmsManager smsManager;

    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();
    // integer for permissions results request
    private static final int ALL_PERMISSIONS_RESULT = 1011;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest mLocationRequest;
    private LocationCallback mlocationCallback;
    private LocationSettingsRequest.Builder builder;
    private static final int REQUEST_CHECK_SETTINGS = 102;
    private LocationCallback locationCallback;
    LocationRequest locationRequest = new LocationRequest();
    boolean x = false;
    private long UPDATE_INTERVAL = 10 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */
    private Location currentLocation = new Location("");

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRefMessage = database.getReference("message");
    DatabaseReference myRefLat = database.getReference("Users/Jaxon/Location/Lat");
    DatabaseReference myRefLong = database.getReference("Users/Jaxon/Location/Long");

    public interface OnIntegerChangeListener
    {
        public void onIntegerChanged(int newValue);
    }

    public class ObservableInteger
    {
        private OnIntegerChangeListener listener;

        private int value;

        public void setOnIntegerChangeListener(OnIntegerChangeListener listener)
        {
            this.listener = listener;
        }

        public int get()
        {
            return value;
        }

        public void set(int value)
        {
            this.value = value;

            if(listener != null)
            {
                listener.onIntegerChanged(value);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_selection);

        contactsList = findViewById(R.id.contactsList);

        contactsArray = getResources().getStringArray(R.array.contacts);

        contactsAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, contactsArray);

        contactsList.setAdapter(contactsAdapter);

        contactsList.setOnItemClickListener(this);

        sendAlertButton = findViewById(R.id.newContactEditTextButton);
        sendAlertButton.setOnClickListener(this);
        et = findViewById(R.id.newContactEditText);

        sendTextEdit = findViewById(R.id.sendMessageEdit);
        sendTextButton = findViewById(R.id.sendMessageButton);
        sendTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(findViewById(android.R.id.content),
                        "'" + sendTextEdit.getText() + "' sent to Contact",
                        Snackbar.LENGTH_SHORT).show();
            }
        });

        smsManager = SmsManager.getDefault();

        //add permissions to request location of user
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);

        permissionsToRequest = permissionsToRequest(permissions);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0) {
                requestPermissions(permissionsToRequest.toArray(
                        new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
            }
        }

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    // ...
                }
            }
        };


        //mDatabase = FirebaseDatabase.getInstance().getReference();

    }

//    @IgnoreExtraProperties
//    public class User {
//
//        public String Contacts;
//        public String Location;
//        public String Phone;
//
//        public User() {
//            // Default constructor required for calls to DataSnapshot.getValue(User.class)
//        }
//
//        public User(String Contacts, String Location, String Phone) {
//            this.Contacts = Contacts;
//            this.Phone = Phone;
//            this.Location = Location;
//        }
//
//    }

//    public void writeNewUser(String userId, String location, String phone) {
//        User user = new User("Jaxon", "Lat: 1 Long: 2", "3013055468" );
//
//        mDatabase.child("users").child(userId).setValue(user);
//    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();

        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(this);
        alertDialog2.setTitle("WARNING");
        alertDialog2.setMessage("Are you sure you want to exit?");
        // Add the buttons
        alertDialog2.setPositiveButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                //Here i am doing JSON Stuff
                JSONObject commandData = new JSONObject();

            }
        });
        alertDialog2.setNegativeButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Snackbar.make(findViewById(android.R.id.content),
                        "Message sent to contact",
                        Snackbar.LENGTH_LONG).show();

                ContactSelection.super.onBackPressed();
            }
        });
        alertDialog2.show();
    }

    private ArrayList<String> permissionsToRequest(ArrayList<String> permissions) {
        ArrayList<String> result = new ArrayList<>();

        for (String perm : permissions) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }

        return result;

    }

    private boolean hasPermission(String perm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
        }

        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        //get the name(s) selected
        if (view instanceof TextView) {

            if(!isLocationEnabled(this)) {
                //IF LOCATION SERVICES DISABLED
                String nameClicked = "Location Services Disabled. Intended Destination Sent to " + ((TextView) view).getText().toString();
//send SMS with current location & Destination
                //int number = 301; //NEEDS TO BE UPDATED TO nameClicked.NUMBER
                String uri = "Your friend _____ is headed to Gate 1";

                //SEND TEXT (using notifications now to test)
                NotificationCompat.Builder builder = new NotificationCompat.Builder(ContactSelection.this)
                        .setSmallIcon(R.drawable.ic_android_black_24dp)
                        .setContentTitle("Text Message")
                        .setContentText(uri)
                        .setAutoCancel(true);
                //smsManager.sendTextMessage(String.valueOf(number), null, uri, null, null);



                Intent tempintent = new Intent(ContactSelection.this, NotificationActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(ContactSelection.this, 0, tempintent, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                //SEND LOCATION TO SERVER
                //HARD CODED TO UPDATE JAXONS LOCATION
                myRefLat.setValue(currentLocation.getLatitude());
                myRefLong.setValue(currentLocation.getLongitude());
                Log.e("SERV", "Lat:"+currentLocation.getLatitude());

                NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

                notificationManager.notify(0, builder.build());

                Snackbar.make(findViewById(android.R.id.content),
                        nameClicked,
                        Snackbar.LENGTH_SHORT).show();


                // back to expect me page
                //Intent intent = new Intent(this, ExpectMeActivity.class);

                //startActivity(intent);
            }
            else {
                //IF LOCATION SERVICES ENABLED
                String nameClicked = "Current Location (38.9776, -76.4878) and Destination Sent to " + ((TextView) view).getText().toString();

                //send SMS with current location & Destination
                int number = 301; //NEEDS TO BE UPDATED TO nameClicked.NUMBER
                double latitude = 38.9776;
                double longitude = -76.4878;
                String uri = "Your friend _____ is here:" + "http://maps.google.com/maps?saddr=" + latitude + "," + longitude + "and is headed to:" + "Gate 1";

                //SEND TEXT (****using notification to test*****)
                NotificationCompat.Builder builder = new NotificationCompat.Builder(ContactSelection.this)
                        .setSmallIcon(R.drawable.ic_android_black_24dp)
                        .setContentTitle("Text Message")
                        .setContentText(uri)
                        .setAutoCancel(true);
                //smsManager.sendTextMessage(String.valueOf(number), null, uri, null, null);


                //SEND LOCATION TO SERVER
                //HARD CODED TO UPDATE JAXONS LOCATION
                myRefLat.setValue(String.valueOf(latitude));
                myRefLong.setValue(String.valueOf(longitude));
                Log.e("SERV", "Lat:"+latitude);

                Intent tempintent = new Intent(ContactSelection.this, NotificationActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(ContactSelection.this, 0, tempintent, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);


                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                notificationManager.notify(0, builder.build());

                Snackbar.make(findViewById(android.R.id.content),
                        nameClicked,
                        Snackbar.LENGTH_SHORT).show();


                //LOCATION CHECKER

                fusedLocationClient = getFusedLocationProviderClient(this);
                final Location targetLocation = new Location("");
                targetLocation.setLatitude(38.9777);
                targetLocation.setLongitude(-76.4832717);


                fusedLocationClient.getLastLocation()
                        .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                // Got last known location. In some rare situations this can be null.
                                //CHECKING LOCATION FOR GATE 1
                                if (location != targetLocation && location != null) {
                                    Snackbar.make(findViewById(android.R.id.content), "Current Location and Destination Sent to Contact",
                                            Snackbar.LENGTH_SHORT).show();

                                }
                            }
                        });

                startLocationUpdates();
                onLocationChanged(currentLocation);
                //MAKE 20m RADIUS check
                final double radiusInMeters = 0.05 * 1000.0; //1 KM = 1000 Meter
                Log.e("HELLO", "GOT HERE");


                final Runnable myRunnable = new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        Log.e("HELLO", "RUNNING1");
                        float distance = 100;


//                        // Write a message to the database
//                        FirebaseDatabase database = FirebaseDatabase.getInstance();
//                        // 'Jaxon' hardcoded. Should be user
//                        DatabaseReference myRef = database.getReference();
//
//
//                        myRef.setValue("USER x is headed to gate 1. Current Location: ");

                        while (distance > radiusInMeters) {
                            try {
                                Thread.sleep(5000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            Log.e("HELLO", "RUNNING");
                            Log.e("HELLO", "GOT HERE");
//                            writeNewUser("Jaxon", "Lat: 1 Long: 2", "3013055468" );

                            onLocationChanged(currentLocation);

                            //SEND LOCATION TO SERVER
                            //HARD CODED TO UPDATE JAXONS LOCATION
                            //NEEDS UPDATED LOCATION, RETURNING 0.0, but updating...
//                            myRefLat.setValue(String.valueOf(currentLocation.getLatitude()));
//                            myRefLong.setValue(String.valueOf(currentLocation.getLongitude()));
//                            Log.e("SERV", "Lat:"+currentLocation.getLatitude());

                            distance = currentLocation.distanceTo(targetLocation);
                            int resultInt = Math.round(distance);
                            Snackbar.make(findViewById(android.R.id.content), "You're on the Move! " + Integer.toString(resultInt) + " meters away.",
                                    Snackbar.LENGTH_SHORT).show();

                            if (distance <= radiusInMeters) {
                                Snackbar.make(findViewById(android.R.id.content), "YOU HAVE ARRIVED! Notification sent to contact. Press Back Button to return to Expect Me",
                                        Snackbar.LENGTH_INDEFINITE).show();

                                return;


                            }
                            Log.e("HELLO", Float.toString(distance));

                        }
                    }
                };

                Thread myThread = new Thread(myRunnable);
                myThread.start();


                //DO BELOW AFTER REACHED DESTINATION
                // Intent Back2MainIntent = new Intent(this, MainActivity.class);
                // startActivity(Back2MainIntent);



            }
        }
    }

    public void arrived() {

        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("You've Arrived")
                .setMessage("Would you like to close this app?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();

    }

    @Override
    public void onClick(View v) {
        if (!isLocationEnabled(this)) {
            String nameClicked = "Location Services disabled. Intended Destination Sent to " + et.getText().toString();
            Snackbar.make(findViewById(android.R.id.content),
                    nameClicked,
                    Snackbar.LENGTH_SHORT).show();

            //SEND TEXT (using notifications now to test)
            NotificationCompat.Builder builder = new NotificationCompat.Builder(ContactSelection.this)
                    .setSmallIcon(R.drawable.ic_android_black_24dp)
                    .setContentTitle("Text Message")
                    .setContentText(nameClicked) //NEEDS TO BE DESTINATION
                    .setAutoCancel(true);
            //smsManager.sendTextMessage(String.valueOf(number), null, uri, null, null);

            Intent tempintent = new Intent(ContactSelection.this, NotificationActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(ContactSelection.this, 0, tempintent, PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentIntent(pendingIntent);


            NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(0, builder.build());
            // back to expect me page
            Intent intent = new Intent(this, ExpectMeActivity.class);

            //startActivity(intent);

        } else {
            String nameClicked = "Current Location and Destination Sent to " + et.getText().toString();

            //SEND TEXT (using notifications now to test)
            NotificationCompat.Builder builder = new NotificationCompat.Builder(ContactSelection.this)
                    .setSmallIcon(R.drawable.ic_android_black_24dp)
                    .setContentTitle("Text Message")
                    .setContentText(nameClicked) //NEEDS TO BE DESTINATION
                    .setAutoCancel(true);
            //smsManager.sendTextMessage(String.valueOf(number), null, uri, null, null);

            Intent tempintent = new Intent(ContactSelection.this, NotificationActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(ContactSelection.this, 0, tempintent, PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentIntent(pendingIntent);


            NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(0, builder.build());

            Snackbar.make(findViewById(android.R.id.content),
                    nameClicked,
                    Snackbar.LENGTH_SHORT).show();

            // back to expect me page
            Intent intent = new Intent(this, ExpectMeActivity.class);

            //startActivity(intent);
        }
    }

    public static boolean isLocationEnabled(Context context) {
        int locationMode = 0;
        String locationProviders;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
            try {
                locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);

            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
                return false;
            }

            return locationMode != Settings.Secure.LOCATION_MODE_OFF;

        }else{
            locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }



    }

    @Override
    protected void onResume() {
        super.onResume();
        startLocationUpdates();

    }

    private void startLocationUpdates() {

        // Create the location request to start receiving updates
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Create LocationSettingsRequest object using location request
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = builder.build();

        // Check whether location settings are satisfied
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // new Google API SDK v11 uses getFusedLocationProviderClient(this)
        getFusedLocationProviderClient(this).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // do work here
                        onLocationChanged(locationResult.getLastLocation());
                    }
                },
                Looper.myLooper());
    }


    public void onLocationChanged(Location location) {
        // New location has now been determined
        String msg = "Updated Location: " +
                Double.toString(location.getLatitude()) + "," +
                Double.toString(location.getLongitude());
        //Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        // You can now create a LatLng Object for use with maps
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        currentLocation = location;
    }

    public void getLastLocation() {
        // Get last known recent location using new Google Play Services SDK (v11+)
        FusedLocationProviderClient locationClient = getFusedLocationProviderClient(this);

        locationClient.getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // GPS location can be null if GPS is switched off
                        if (location != null) {
                            onLocationChanged(location);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("MapDemoActivity", "Error trying to get last GPS location");
                        e.printStackTrace();
                    }
                });
    }

    private void checkDistance(final double radiusInMeters, final Location targetLocation) {
        new Thread(new Runnable() {
            public void run() {
                float[] results = new float[1];
                while(results[0] > radiusInMeters) {

                    int resultInt = Math.round(results[0]);
                    Snackbar.make(findViewById(android.R.id.content), Integer.toString(resultInt),
                            Snackbar.LENGTH_SHORT).show();
                    Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), targetLocation.getLatitude(), targetLocation.getLongitude(), results);

                    if(results[0] <= radiusInMeters) {
                        Snackbar.make(findViewById(android.R.id.content), "YOU HAVE ARRIVED",
                                Snackbar.LENGTH_SHORT).show();
                        x = true;
                        break;
                    }
                }
            }
        }).start();
    }

    public void back2Main() {
        Intent Back2MainIntent = new Intent(this, MainActivity.class);
        startActivity(Back2MainIntent);
    }

}
