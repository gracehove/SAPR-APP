package edu.usna.mobileos.saprapp2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import edu.usna.mobileos.saprapp2.R;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;
import static edu.usna.mobileos.saprapp2.ContactSelection.isLocationEnabled;

public class PathDevActivity extends AppCompatActivity {

    private Button startButton;
    private Location currentLocation = new Location("");
    private boolean x = false;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest mLocationRequest;

    private long UPDATE_INTERVAL = 10 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_path_dev);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Write a message to the database
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("message");

                    myRef.setValue("JAXON");


                    run();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        new AlertDialog.Builder(PathDevActivity.this).
                setMessage("Are you Driving or Walking to your Destination?").
                setPositiveButton("Walking", null).
                setNegativeButton("Driving", null).create().show();

        return;

    }

    private void run() throws InterruptedException {
        statusCheck();

        //SEND MESSAGE TO SERVER HERE
        Snackbar.make(findViewById(android.R.id.content),
                "Path Deviation started. Contacts have been notified",
                Snackbar.LENGTH_SHORT).show();

        //ACTUAL PATH DEVIATION
        fusedLocationClient = getFusedLocationProviderClient(this);
        final Location targetLocation = new Location("");
        targetLocation.setLatitude(38.9777);
        targetLocation.setLongitude(-76.4832717);


        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        //CHECKING LOCATION FOR GATE 1
                        if (location != targetLocation && location != null) {
                            Snackbar.make(findViewById(android.R.id.content), "Current Location and Destination Sent to Contact",
                                    Snackbar.LENGTH_SHORT).show();

                        }
                    }
                });

        startLocationUpdates();
        onLocationChanged(currentLocation);
        //MAKE 20m RADIUS check compared to starting distance
        final double startingDistance = currentLocation.distanceTo(targetLocation);
        final double radiusInMeters = 0.05 * 1000; //1 KM = 1000 Meter
        Log.e("HELLO", "GOT HERE");


        final Runnable myRunnable = new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                Log.e("HELLO", "RUNNING1");
                float distance = 15;

                //SEND LOCATION TO SERVER


//                        // Write a message to the database
//                        FirebaseDatabase database = FirebaseDatabase.getInstance();
//                        // 'Jaxon' hardcoded. Should be user
//                        DatabaseReference myRef = database.getReference();
//
//
//                        myRef.setValue("USER x is headed to gate 1. Current Location: ");

                while (true) {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.e("HELLO", "RUNNING");
                    Log.e("HELLO", "GOT HERE");
//                            writeNewUser("Jaxon", "Lat: 1 Long: 2", "3013055468" );

                    onLocationChanged(currentLocation);

                    distance = currentLocation.distanceTo(targetLocation);


                    double resultInt = Math.round(distance);
                    Snackbar.make(findViewById(android.R.id.content), "You're on the Move! " + Double.toString(resultInt) + " meters off path.",
                            Snackbar.LENGTH_SHORT).show();

//                    if (distance <= radiusInMeters) {
//                        Snackbar.make(findViewById(android.R.id.content), "YOU HAVE ARRIVED! Notification sent to contact. Press Back Button to return to Expect Me",
//                                Snackbar.LENGTH_INDEFINITE).show();
//
//                        return;
//
//
//                    }
                    if (distance >= 20) {
                        Log.e("HELLO", "DISTANCE TRIGGERED");
                        x = true;
                        Snackbar.make(findViewById(android.R.id.content), "You've deviated too far. Contacts notified. Press button to restart.",
                                Snackbar.LENGTH_LONG).show();
                        return;

                    }


                }


            }

            ;
        };

        Thread myThread = new Thread(myRunnable);
        myThread.start();
        Log.e("HELLO", "IN FUNCTION");

        while (x != true) {
            int y = 1;
            if (x == true) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(PathDevActivity.this);
                builder.setMessage("You're getting further away. Your contact has been alerted. End Path Deviation?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int id) {
                                PathDevActivity.super.onBackPressed();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int id) {
                                dialog.cancel();
                            }
                        });
                final AlertDialog alert = builder.create();
                alert.show();
            }
        }

    }


    private void startLocationUpdates() {
        // Create the location request to start receiving updates
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Create LocationSettingsRequest object using location request
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = builder.build();

        // Check whether location settings are satisfied
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // new Google API SDK v11 uses getFusedLocationProviderClient(this)
        getFusedLocationProviderClient(this).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // do work here
                        onLocationChanged(locationResult.getLastLocation());
                    }
                },
                Looper.myLooper());
    }

    private void checkDistance(final double radiusInMeters, final Location targetLocation) {
        //LOCATION CHECKER
        new Thread(new Runnable() {
            public void run() {
                float[] results = new float[1];
                while(results[0] > radiusInMeters) {

                    int resultInt = Math.round(results[0]);
                    Snackbar.make(findViewById(android.R.id.content), Integer.toString(resultInt),
                            Snackbar.LENGTH_SHORT).show();
                    Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), targetLocation.getLatitude(), targetLocation.getLongitude(), results);

                    if(results[0] <= radiusInMeters) {
                        Snackbar.make(findViewById(android.R.id.content), "YOU HAVE ARRIVED",
                                Snackbar.LENGTH_SHORT).show();
                        x = true;
                        break;
                    }
                }
            }
        }).start();

    }

    public static boolean isLocationEnabled(Context context) {
        int locationMode = 0;
        String locationProviders;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);

            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
                return false;
            }

            return locationMode != Settings.Secure.LOCATION_MODE_OFF;

        } else {
            locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }


    }

    public void statusCheck() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    public void onLocationChanged(Location location) {
        // New location has now been determined
        String msg = "Updated Location: " +
                Double.toString(location.getLatitude()) + "," +
                Double.toString(location.getLongitude());
        //Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        // You can now create a LatLng Object for use with maps
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        currentLocation = location;
    }

    private void showAlert() {


    }

}