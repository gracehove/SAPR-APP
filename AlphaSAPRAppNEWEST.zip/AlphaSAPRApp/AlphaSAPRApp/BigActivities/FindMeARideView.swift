//
//  FindMeARideView.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/24/21.
//
import SwiftUI
import MapKit

struct FindMeARideView: View {
    @ObservedObject private var locationManager = LocationManager()
    @EnvironmentObject var modelData: ModelData
    @EnvironmentObject var locationData: LocationData
    //Do not display deletet contacts:
    var filteredContacts: [Contact] {
        //WE SWITCHED THIS BACK. MAY CRASH
        modelData.myContacts.filter { contact in
            (!contact.isInactive)
        }
    }
    var body: some View {
        let coordinate = locationManager.center != nil ? locationManager.center : CLLocationCoordinate2D()
        NavigationView {
            VStack {
                Map(coordinateRegion: $locationManager.region, showsUserLocation: true)
                    .frame(height: 175)
                
                Spacer()
                NavigationLink(destination: ContactListMsg(contactsToCall: filteredContacts)){
                    HStack {
                        Image(systemName: "location.fill")
                        Text("Share my Location")
                    }
                }
                
                Spacer()
                NavigationLink(destination: ContactList(contactsToCall: filteredContacts)) {
                    HStack {
                        Image(systemName: "phone.fill")
                        Text("Call my Friends")
                    }
                }
                Spacer()
                Button("Call Shipmate"){
                    print("Location Shared")
                    call(phoneNumber: "tel://4103205961")
                }
                Spacer()
                Button("Call a Taxi"){
                    print("Location Shared")
                    call(phoneNumber: "tel://4439950022")
                }
            }
        }
    }
}

func call(phoneNumber: String) -> Void{
    print ("Calling", phoneNumber)
    guard let url = URL(string: phoneNumber) else {return}
    UIApplication.shared.open(url)
}

struct FindMeARideView_Previews: PreviewProvider {
    static var previews: some View {
        FindMeARideView()
            .environmentObject(ModelData())
    }
}
