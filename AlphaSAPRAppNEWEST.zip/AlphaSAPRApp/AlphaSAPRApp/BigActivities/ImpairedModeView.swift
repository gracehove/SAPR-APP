//
//  ImpairedModeView.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/24/21.
//

import SwiftUI
import MapKit

struct ContactList: View {
    var contactsToCall: [Contact]
    var body: some View {
        NavigationView {
            List(contactsToCall) {
                contact in ListRow(eachContact: contact)
            }.navigationBarTitle(Text("Friends"))
        }
    }
}

struct ContactListMsg: View {
    var contactsToCall: [Contact]
    var body: some View {
        NavigationView {
            List(contactsToCall) {
                contact in ListRowMsg(eachContact: contact)
            }.navigationBarTitle(Text("Friends"))
        }
    }
}

struct ListRow: View {
    @EnvironmentObject var modelData: ModelData
    @EnvironmentObject var locationData: LocationData
    @State private var timeRemaining = 7
    @State private var isActive = true
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var eachContact: Contact
    var body: some View {
        HStack {
            Text(eachContact.name)
            Spacer()
            Button(action: {
                let telephone = "tel://"
                let formattedString = telephone + eachContact.phoneNumber
                guard let url = URL(string: formattedString) else {return}
                UIApplication.shared.open(url)
            }) {
                Text(eachContact.phoneNumber)
            }
        } .onReceive(timer, perform: { _ in
            guard self.isActive else {return}
            if self.timeRemaining > 0 {
                self.timeRemaining -= 1
            }
            else if self.timeRemaining == 0 {
                self.timer.upstream.connect().cancel()
                let firstContactPhone = modelData.myContacts[0].phoneNumber
                let formattedString = "tel://" + firstContactPhone
                guard let url = URL(string: formattedString) else {return}
                UIApplication.shared.open(url)
            }
        })
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            self.isActive = false
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            self.isActive = true
        }
    }
}

struct ListRowMsg: View {
    @EnvironmentObject var modelData: ModelData
    @EnvironmentObject var locationData: LocationData
    @ObservedObject private var locationManager = LocationManager()
    @State private var timeRemaining = 7
    @State private var isActive = true
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var eachContact: Contact
    var body: some View {
        let coordinate = self.locationManager.center != nil ? self.locationManager.center : CLLocationCoordinate2D()
        HStack {
            Text(eachContact.name)
            Spacer()
            Button(action: {
                self.timer.upstream.connect().cancel()
                let sms: String = "sms:\(eachContact.phoneNumber)&body=I'm impaired: Here is my location \(coordinate.latitude) \(coordinate.longitude)"
                let strURL: String = sms.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                UIApplication.shared.open(URL.init(string: strURL)!, options: [:], completionHandler: nil)
            }) {
                Text(eachContact.phoneNumber)
            }
        } .onReceive(timer, perform: { _ in
            guard self.isActive else {return}
            if self.timeRemaining > 0 {
                self.timeRemaining -= 1
            }
            else if self.timeRemaining == 0 {
                self.timer.upstream.connect().cancel()
                let firstContactPhone = modelData.myContacts[0].phoneNumber
                let sms = "sms: \(firstContactPhone)&body=I'm impaired: Here is my location \(coordinate.latitude) \(coordinate.longitude)"
                let strURL: String = sms.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                UIApplication.shared.open(URL.init(string: strURL)!, options: [:], completionHandler: nil)
            }
        })
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            self.isActive = false
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            self.isActive = true
        }
    }
}

struct ImpairedModeView: View {
    //var numSavedCont = myContacts.count
    @EnvironmentObject var modelData: ModelData
    @EnvironmentObject var locationData: LocationData
    @State var showSafeWalk = false
    @State var showDetails = false
    @State var showAlertSafe = false

    //Do not display deletet contacts:
    var filteredContacts: [Contact] {
        //WE SWITCHED THIS BACK. MAY CRASH
        modelData.myContacts.filter { contact in
            (!contact.isInactive)
        }
    }
    //Do not display deleted locations:
    var filteredLocations: [Location] {
        //WE SWITCHED THIS BACK. MAY CRASH
        locationData.myLocations.filter { location in
            (!location.isInactive)
        }
    }
    
    
    var body: some View {
        
        NavigationView{
            VStack{
                VStack{
                    if filteredContacts.count > 0 {
                        NavigationLink(destination: ContactList(contactsToCall: filteredContacts)) {
                            HStack {
                                Image(systemName: "phone.fill")
                                Text("Call my Friends")
                                    .font(.title)
                                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            }
                            .padding(50)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(40)
                        }
                        .padding(15)
                        
                        NavigationLink(destination: ContactListMsg(contactsToCall: filteredContacts)){
                            HStack {
                                Image(systemName: "location.fill")
                                Text("Share my Location")
                                    .font(.title)
                                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            }
                            .padding(45)
                            .foregroundColor(.white)
                            .background(Color.orange)
                            .cornerRadius(40)
                        }
                        .padding(15)
                    }
                    Button(action: {
                        self.showDetails.toggle()
                    }) {
                        HStack {
                            Image(systemName: "phone.fill")
                            Text("Call the Police")
                                .font(.title)
                                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        }
                        .padding(50)
                        .foregroundColor(.white)
                        .background(Color.red)
                        .cornerRadius(40)
                    }
                    .padding(15)
                }
                .alert(isPresented: $showDetails) { () -> Alert in
                    let primaryButton = Alert.Button.default(Text("OK")) {
                        let formattedString = "tel://123456789" //CHANGE TO 911 AFTER DEMO PHASE
                        guard let url = URL(string: formattedString) else {return}
                        UIApplication.shared.open(url)
                    }
                    let secondaryButton = Alert.Button.cancel(Text("Cancel")) {}
                    return Alert(title: Text("Call the Police"), message: Text("Pressing OK will call 911"), primaryButton: primaryButton, secondaryButton: secondaryButton)
                }
            }
            .navigationTitle("Impaired Mode")
        }
    }
}


struct ImpairedModeView_Previews: PreviewProvider {
    static var previews: some View {
        ImpairedModeView()
            .environmentObject(ModelData())
            .environmentObject(LocationData())
    }
}
