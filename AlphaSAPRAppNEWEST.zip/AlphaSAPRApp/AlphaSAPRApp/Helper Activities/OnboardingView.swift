//
//  OnboardingView.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/24/21.
//

import SwiftUI

struct OnboardingView: View {
    @Binding var isOnboardingViewShowing: Bool
    @State private var nameText: String = ""
    @State private var phoneNumer: String = ""
    
    var body: some View {
        TabView {
            VStack {
                Text("Welcome")
                    .font(.title)
                    .padding()
                Text("Please enter in your Information:")
                    .padding()
                
                TextField("Your Name",text: $nameText)
                    .frame(width: 300, height: 65)
                TextField("(123)456-7890",text: $phoneNumer)
                    .frame(width: 300, height: 65)
                    .keyboardType(.namePhonePad)
            } .textFieldStyle(RoundedBorderTextFieldStyle())
            VStack{
                Text("Would you like to customize settings?")
                HStack {
                    Button(action: {isOnboardingViewShowing.toggle()}, label: {
                        Text("No")
                            .foregroundColor(.red)
                    }).padding()
                    
                    Button(action: {isOnboardingViewShowing.toggle(); goSettings()}, label: {
                        Text("Yes")
                    }).padding()
                }
            }
        }.tabViewStyle(PageTabViewStyle())
        
    }
}

func goSettings() {
    if let window = UIApplication.shared.windows.first{
        window.rootViewController = UIHostingController(rootView: SettingsView())//initialSettingsView(isOnboardingViewShowing: Binding.constant(true)))
        window.makeKeyAndVisible()
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        
        OnboardingView(isOnboardingViewShowing: Binding.constant(true))
    }
}
