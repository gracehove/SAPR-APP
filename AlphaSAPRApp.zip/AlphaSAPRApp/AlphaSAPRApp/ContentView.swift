//
//  ContentView.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house")
                    Text("HOME")
                }
            SettingsView()
                .tabItem {
                    Image(systemName: "gear")
                    Text("SETTINGS")
                }
            
            /*MapView()
                .tabItem{
                    Image(systemName: "globe")
                    Text("MAP")
                }*/
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(ModelData())
            .environmentObject(LocationData())
    }
}

struct HomeView: View {
    var body: some View {
        NavigationView {
            VStack {

                Spacer()
                
                //Expect Me
                NavigationLink("Expect Me", destination: ExpectMeView())
                
                Spacer()
                
                //Find Me A Ride
                Button("Find Me A Ride"){
                    //Navigate to Find Me A Ride
                }
                
                Spacer()
                
                //Time to Leave
                Button("Time To Leave"){
                    //Navigate to Time To Leave
                }
                
                Spacer()
                
                //SAPR Information Center
                Button("SAPR Information Center"){
                    //Navigate to SAPR Information Center
                }
                
                Spacer()
                
            }
            .navigationTitle("Home")
        }
    }
}
