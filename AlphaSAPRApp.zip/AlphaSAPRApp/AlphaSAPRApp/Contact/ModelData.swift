//
//  ModelData.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/23/21.
//

import Foundation
import Combine
import Contacts

final class ModelData: ObservableObject{
    //Simulation of loading the contacts
    //var contacts = CNMutableContact()
    
    @Published var myContacts: [Contact] = [
        Contact(id: 1, phoneNumber: "7016210161", name: "Grace", isInactive: false),
        Contact(id: 2, phoneNumber: "9155393732", name: "Alex", isInactive: false),
        Contact(id: 3, phoneNumber: "4064316475", name: "Kendall", isInactive: false),
        Contact(id: 4, phoneNumber: "5303041968", name: "Darby", isInactive: false),
        Contact(id: 5, phoneNumber: "3142776804", name: "JP", isInactive: false)
    ]
    
}
//COME BACK HERE
