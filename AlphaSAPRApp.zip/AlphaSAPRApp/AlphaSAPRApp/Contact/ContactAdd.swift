//
//  ContactAdd.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/23/21.
//


import SwiftUI

struct ContactAdd: View {
    @EnvironmentObject var modelData: ModelData
    @State private var name: String = ""
    @State private var number: String = ""
    
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Spacer()
                Image(systemName: "person.fill")
                    .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                    .frame(width: 36.0, height: 39.0)
                Spacer()
            }
            Text("Contact Name:")
                .font(.largeTitle)
            TextField("John Doe", text: $name)
                .padding(.leading)
            Text("Contact Number:")
                .font(.largeTitle)
            TextField("(123) 456-7890", text: $number)
                .padding(.leading)
            HStack{
                Spacer()
                Button(action: {
                    //Update
                    if(name != "" && number != "") {
                        var newContact: Contact = Contact(id: (modelData.myContacts.count + 1), phoneNumber: number, name: name, isInactive: false)
                        modelData.myContacts.append(newContact)
                    }
                    
                }, label: {
                    Text("Add")
                })
                Spacer()
            }
            .padding(.top)
            
        }
        .padding(.trailing)
    }
}

struct ContactAdd_Previews: PreviewProvider {
    static var modelData = ModelData()
    
    static var previews: some View {
        ContactAdd()
            .environmentObject(modelData)
    }
}
