//
//  DeleteButton.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/23/21.
//

import SwiftUI

struct DeleteButton: View {
    @Binding var isSet: Bool
    
    var body: some View {
        Button(action: {
            isSet.toggle();
        }) {
            HStack{
                Text("Delete")
                Image(systemName: "trash")
            }
            .padding(7)
            .foregroundColor(.white)
            .background(Color.red)
            .cornerRadius(15)
        }
    }
}

struct DeleteButton_Previews: PreviewProvider {
    static var previews: some View {
        DeleteButton(isSet: .constant(true))
    }
}
