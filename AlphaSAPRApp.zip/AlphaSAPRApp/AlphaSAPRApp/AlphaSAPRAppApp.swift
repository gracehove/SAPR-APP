//
//  AlphaSAPRAppApp.swift
//  AlphaSAPRApp
//
//  Created by Alex Hernandez on 3/23/21.
//

import SwiftUI

@main
struct AlphaSAPRAppApp: App {
    @StateObject private var modelData = ModelData()
    @StateObject private var locationData = LocationData()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modelData)
                .environmentObject(locationData)
        }
    }
}
