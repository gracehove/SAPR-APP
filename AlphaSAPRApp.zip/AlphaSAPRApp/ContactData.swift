//
//  ContactData.swift
//  Hove_Prototype
//
//  Created by Johnson, Kendall Midn USN USNA Annapolis on 2/21/21.
//

import SwiftUI

struct ContactData: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ContactData_Previews: PreviewProvider {
    static var previews: some View {
        ContactData()
    }
}
