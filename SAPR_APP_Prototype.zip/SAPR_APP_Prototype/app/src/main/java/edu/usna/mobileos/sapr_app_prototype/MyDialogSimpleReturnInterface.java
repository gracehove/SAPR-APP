package edu.usna.mobileos.sapr_app_prototype;

import java.util.HashMap;

public interface MyDialogSimpleReturnInterface {

    public void onDialogSimpleItemClick(String choice);

}
