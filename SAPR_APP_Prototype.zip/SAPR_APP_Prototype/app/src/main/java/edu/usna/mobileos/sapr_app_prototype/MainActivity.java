package edu.usna.mobileos.sapr_app_prototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements MyDialogReturnInterface, MyDialogSimpleReturnInterface{

    Intent intent;
    private String userName;
    private String userNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //We are going to need to set some functionality so that some of this data is persisting.
        //Then we will enable a flag that will be set to false after the first use of the app.
        Greeting1Dialog dialog = new Greeting1Dialog();
        dialog.show(getSupportFragmentManager(), "Greeting1Dialog");

    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle item selection
        switch(item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Button Click Responses launch different activities
     */
    public void launchExpectMe(View view) {
        //Launch the expect me activity
    }

    public void launchTimeToLeave(View view) {
        //Launch the time to leave activity
        Intent intent = new Intent(this, TimeToLeave2Activity.class);
        startActivity(intent);
        finish();
    }


    public void launchFindMeARide(View view) {
        //Launch the find me a ride activity
        Intent intent = new Intent(this, FindMeARideActivity.class);
        startActivity(intent);
        finish();
    }

    public void launchSAPRInformationCenter(View view) {
        //Launch the SAPR Information Center activity
        Intent intent = new Intent(this, SAPRInformationCenter.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onDialogItemClick(HashMap<String, String> item) {
        //This will only have one element but that's ok


        for (String k : item.keySet()) {
            String phoneNumber = item.get(k);
            if(phoneNumber.length() != 10){
                Toast.makeText(getBaseContext(),"INVALID PHONE NUMBER", Toast.LENGTH_SHORT).show();
                //RELAUNCH THE SAME DIALOG
                Greeting1Dialog dialog = new Greeting1Dialog();
                dialog.show(getSupportFragmentManager(), "Greeting1Dialog");
                break;
            }
            else {
                phoneNumber = "tel:+" + phoneNumber;
                //Set user information
                userName = k;
                userNumber = phoneNumber;

                //LAUNCH THE NEXT DIALOG
                Greeting2Dialog dialog = new Greeting2Dialog();
                dialog.show(getSupportFragmentManager(), "Greeting2Dialog");
                break;
            }
        }
    }

    @Override
    public void onDialogSimpleItemClick(String choice) {
        if(choice.equals("Positive")){
            Intent intent1 = new Intent(this, SettingsActivity.class);
            startActivity(intent1);
            finish();
        }
    }
}

