package edu.usna.mobileos.sapr_app_prototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class SAPRInformationCenter extends AppCompatActivity {

    WebView webView;
    String fullURL = "https://usna-sapr-app.web.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_a_p_r_information_center);

        webView = findViewById(R.id.sapr_information_center);

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(fullURL);
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle item selection
        switch(item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent2 = new Intent(this, MainActivity.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}