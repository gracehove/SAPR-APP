package edu.usna.mobileos.sapr_app_prototype;


import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class TimeToLeaveActivity extends AppCompatActivity {

    public EditText sender;
    public EditText message;
    public RadioButton text;
    public RadioButton call;
    String typeContent = "Text";

    MediaRecorder mediaRecorder;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_to_leave);

        sender = findViewById(R.id.senderInfo);
        message = findViewById(R.id.messageInfo);
        text = findViewById(R.id.text_indicator);
        call = findViewById(R.id.call_indicator);

    }

    public void skipSetup(View view) {
        String senderName = "Jacob Smith";
        String messageContent = "we have a duty section muster in 15 minutes.";


        sender.setText(senderName);
        message.setText(messageContent);

        finishSetup(senderName, messageContent, typeContent);
    }

    public void setup(View view) {
        String senderName = String.valueOf(sender.getText());
        String messageContent = String.valueOf(message.getText());

        //Text is already default
        if (call.isChecked())
            typeContent = "Call";
        finishSetup(senderName, messageContent, typeContent);
    }

    private void finishSetup(String name, String msg, String typ) {
        //Launch new workout activity
        Intent intent = new Intent(getBaseContext(), TimeToLeave2Activity.class);
        intent.putExtra("sender", name);
        intent.putExtra("message", msg);
        intent.putExtra("type", typ);
        startActivity(intent);
        finish();
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle item selection
        switch(item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent2 = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }
}


/*
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import android.widget.Toast;

public class TimeToLeaveActivity extends AppCompatActivity {

    public EditText sender;
    public EditText message;
    public RadioButton text;
    public RadioButton call;
    public Button record;
    String typeContent = "Text";

    MediaRecorder mediaRecorder;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_to_leave);

        sender = findViewById(R.id.senderInfo);
        message = findViewById(R.id.messageInfo);
        text = findViewById(R.id.text_indicator);
        call = findViewById(R.id.call_indicator);
        record = findViewById(R.id.record);

        //IMMEDIATELY LAUNCH EXPLANATION DIALOG
        TTLIntroDialog dialog = new TTLIntroDialog();
        dialog.show(getSupportFragmentManager(), "TTLIntroDialog");

    }

    public void skipSetup(View view) {
        String senderName = "Jacob Smith";
        String messageContent = "we have a duty section muster in 15 minutes.";


        sender.setText(senderName);
        message.setText(messageContent);

        finishSetup(senderName, messageContent, typeContent);
    }

    public void setup(View view) {
        String senderName = String.valueOf(sender.getText());
        String messageContent = String.valueOf(message.getText());

        //Text is already default
        if (call.isChecked())
            typeContent = "Call";
        finishSetup(senderName, messageContent, typeContent);
    }

    private void finishSetup(String name, String msg, String typ) {
        //Launch new workout activity
        Intent intent = new Intent(getBaseContext(), TimeToLeave2Activity.class);
        intent.putExtra("sender", name);
        intent.putExtra("message", msg);
        intent.putExtra("type", typ);
        startActivity(intent);
        finish();
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle item selection
        switch(item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent2 = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void recordMessage(View view) {
        String status = String.valueOf(record.getText());
        if(status.equals("RECORD")){
            record.setText("STOP");
            //start recording
            Toast.makeText(getBaseContext(),"Recording Started", Toast.LENGTH_SHORT).show();



        }
        else{
            record.setText("RECORD");
            //stop recording
            Toast.makeText(getBaseContext(),"Recording Finished", Toast.LENGTH_SHORT).show();


        }
    }
} */
