package edu.usna.mobileos.sapr_app_prototype;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class ImpairedModeActivity extends AppCompatActivity implements MyDialogSimpleReturnInterface{

    private HashMap<String, String> contacts = new HashMap<String, String>();
    private AlarmManager alarmManager;
    private String[] choice;
    private String intendedFriend;
    private String actionIntent;
    private boolean flag = false;

    final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impaired_mode);

        TextView Banner = findViewById(R.id.banner);
        Button callMyFriends = findViewById(R.id.friends);
        Button shareMyLocation = findViewById(R.id.location);
        Button callThePolice = findViewById(R.id.police);

        //If there is no contact list passed in the intent!
        //ENABLE THIS LATER
        /**if(contacts.size() == 0){
            callMyFriends.setText("");
            shareMyLocation.setText("");
            callMyFriends.setOnClickListener(null);
            shareMyLocation.setOnClickListener(null);
        } */

        //Add friends to the hash map-> assumption is that this will come from an intent:
        /*
            for object in intent :
                contacts.put("friend","phone number");
         */
        contacts.put("Grace", "tel:+7016210161");
        contacts.put("Darby", "tel:+5303041968");
        contacts.put("Kenzie", "tel:+8103387410");
        contacts.put("Kendall", "tel:+4064316475");
        contacts.put("Alex", "tel:+9155393732");
        contacts.put("Jaxon", "tel:+3013055468");

        //List of names to pass into the dialog constructor
        choice = new String[this.contacts.size()];
        int index = 0;
        for (String k : contacts.keySet()) {
            choice[index] = k;
            index++;
        }

        intendedFriend = choice[0];
    }

    public void countDown(View view) {
        //Count Down'
        //Specify action since this is sharing a dialog
        this.actionIntent = "call";

        Toast.makeText(getBaseContext(), "you clicked the button - timer has been initiated!", Toast.LENGTH_SHORT).show();

        //Launch the friends dialog
        launchFriendsDialog(view);

        //Set backup intent in case user is unable to select intended contact.
        final Intent callIntent = new Intent(Intent.ACTION_CALL);
        //Intended contact is default friend value.
        callIntent.setData(Uri.parse(contacts.get(this.intendedFriend)));

        //Intent handler required to ensure 7 second delay.
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Verification of permissions required?
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermission
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }
                //The flag is only true when used hasn't picked their own contact
                if (flag == false) {
                    startActivity(callIntent);
                }
            }
        }, 7000); //7 second delay
    }


    public void shareLocation(View view) {
        //Share Location
        //Specify action since this is sharing a dialog
        this.actionIntent = "location";

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Call ActivityCompat#requestPermissions
            // here to request the missing permissions, and then override
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission.

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_FINE_LOCATION);

        }

        Toast.makeText(getBaseContext(), "you clicked the button - timer has been initiated!", Toast.LENGTH_SHORT).show();

        //Launch the Friend's Dialog
        launchFriendsDialog(view);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[],
                                           int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    //mMap.setMyLocationEnabled(true);
                } else {
                    // permission denied. Disable the
                    // functionality that depends on this permission.
                    //do nothing in this case
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }

    public void callCops(View view) {
        //Call Cops
        //Specify action since this is sharing a dialog
        this.actionIntent = "police";
        launchCopsDialog(view);
    }

    private void launchFriendsDialog(View view) {
        ListDialog dialog4 = new ListDialog(this.choice);
        dialog4.show(getSupportFragmentManager(), "ListDialog");
    }

    private void launchCopsDialog(View view) {
        BasicAlert dialog = new BasicAlert();
        dialog.show(getSupportFragmentManager(), "BasicAlert");
    }

    @Override
    public void onDialogSimpleItemClick(String item) {
        //Set flag to true to halt the auto-call or location share to friend # 1
        this.flag = true;

        //Came from "Call my friends" button
        if(this.actionIntent.equals("call")) {

            if(item.equals("Negative")){
                Toast.makeText(getBaseContext(), "CALL CANCELED", Toast.LENGTH_SHORT).show();
            }
            else {
                //Get the intended friend from the dialog return
                this.intendedFriend = item;

                //Initialize call to intended friend
                final Intent callIntent = new Intent(Intent.ACTION_CALL);

                //Get friend's phone number from class hash map
                callIntent.setData(Uri.parse(contacts.get(item)));

                //Required permissions check
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        } else if(this.actionIntent.equals("location")){ //Came from "Share My Location" button
            if(item.equals("Negative")){
                Toast.makeText(getBaseContext(), "LOCATION SHARE CANCELED", Toast.LENGTH_SHORT).show();
            }
            else {
                //Get the intended friend from the dialog return
                this.intendedFriend = item;
            }
        } else {
            String sentiment = item;
            if(sentiment.equals("Positive")){
                //Call the Police
                //Initialize call to police
                final Intent callIntent = new Intent(Intent.ACTION_CALL);

                //Set phone number to "911" once trouble shooting is done                           <- ACTION ITEM
                callIntent.setData(Uri.parse("tel:+1234567890"));
                //Required permissions check
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
            else {
                Toast.makeText(getBaseContext(), "CALL CANCELED", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
