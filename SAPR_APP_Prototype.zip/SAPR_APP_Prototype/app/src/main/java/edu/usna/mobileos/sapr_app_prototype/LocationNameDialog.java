package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;

public class LocationNameDialog extends DialogFragment implements DialogInterface.OnClickListener{

    MyDialogSimpleReturnInterface myInterface;
    EditText name;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        myInterface = (MyDialogSimpleReturnInterface) getActivity();

        //create an alert dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View layout = inflater.inflate(R.layout.location_dialog, null);
        name = layout.findViewById(R.id.locationName);

        builder.setView(layout);

        builder.setTitle("LOCATION")
                .setMessage("Please enter location name:")
                .setPositiveButton("OK", this)
                .setNegativeButton("Cancel", this)
                .setCancelable(false);


        //call create to build the dialog and return it
        return builder.create();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int id) {
        //Return the name of location entered
        String buttonName = "";
        switch (id) {
            case Dialog.BUTTON_NEGATIVE:
                buttonName = "Negative";
                break;
            case Dialog.BUTTON_POSITIVE:
                buttonName = String.valueOf(name.getText());
                break;
        }
        myInterface.onDialogSimpleItemClick(buttonName);
    }
}
