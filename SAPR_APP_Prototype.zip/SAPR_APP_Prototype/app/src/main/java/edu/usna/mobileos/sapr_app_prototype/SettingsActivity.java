package edu.usna.mobileos.sapr_app_prototype;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import android.os.Bundle;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.snackbar.Snackbar;

public class SettingsActivity extends AppCompatActivity implements MyDialogReturnInterface, MyDialogSimpleReturnInterface, AdapterView.OnItemClickListener{

    Intent intent;

    private HashMap<String, String> contacts = new HashMap<String, String>();
    private HashMap<String, LatLng> locations = new HashMap();
    private ArrayList<String> displayedContacts = new ArrayList<>();
    private ArrayList<String> displayedLocations = new ArrayList<>();
    private String[] displayedLocationService = {"OFF"};
    private ListView contactList;
    private ArrayAdapter contactListAdapter;
    private ListView locationList;
    private ArrayAdapter locationListAdapter;
    private ListView locationServiceList;
    private ArrayAdapter locationServiceListAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //Put USNA Gate 1 as the default location shown
        LatLng gate1 = new LatLng(38.978774, -76.484496);
        displayedLocations.add("United States Naval Academy Gate 1");
        locations.put("United States Naval Academy Gate 1", gate1);

        //Search the intent to see if there is there is a location in it.
        intent = getIntent();
        String newName = intent.getStringExtra("newLocation");
        double newLatitude = intent.getDoubleExtra("latitude", 0);
        double newLongitude = intent.getDoubleExtra("longitude", 0);

        if (newName != null){
            LatLng newCoordinates = new LatLng(newLatitude, newLongitude);
            locations.put(newName, newCoordinates);
            displayedLocations.add(newName);
        }

        contactList = findViewById(R.id.contact_list);
        contactList.setOnItemClickListener(this);

        locationList = findViewById(R.id.location_list);
        locationList.setOnItemClickListener(this);

        locationServiceList = findViewById(R.id.locationService_list);


        //Displayed Contacts
        contactListAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, displayedContacts);
        contactList.setAdapter(contactListAdapter);

        //Displayed Locations
        locationListAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, displayedLocations);
        locationList.setAdapter(locationListAdapter);

        //Displayed Location Settings
        locationServiceListAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, displayedLocationService);
        locationServiceList.setAdapter(locationServiceListAdapter);
    }

    public void addContact(View view) {
        //Add a contact -> Launch the contact Dialog
        SimpleAlertDialog dialog = new SimpleAlertDialog();
        dialog.show(getSupportFragmentManager(), "SimpleAlertDialog");
    }

    public void addLocation(View view) {
        //Add a saved location
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
        finish();
    }

    public void updateLocationServices(View view) {
        //Update location services directly in phone settings
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);

    }

    @Override
    public void onDialogItemClick(HashMap<String, String> item) {
        //This will only have one element but that's ok


        for (String k : item.keySet()) {
            if (k.equals("Negative"))
                break;
            else {
                String phoneNumber = item.get(k);
                if(phoneNumber.length() != 10){
                    Toast.makeText(getBaseContext(),"INVALID PHONE NUMBER", Toast.LENGTH_SHORT).show();
                    break;
                }
                else {
                    phoneNumber = "tel:+" + phoneNumber;
                    Toast.makeText(getBaseContext(),"CONTACT ADDED", Toast.LENGTH_SHORT).show();
                    //Add contact to hashmap
                    contacts.put(k, phoneNumber);
                    //Update displayed contacts
                    displayedContacts.add(k);
                    contactListAdapter.notifyDataSetChanged();
                }
            }
        }
    }

    @Override
    public void onDialogSimpleItemClick(String choice) {
        if(choice.equals("Neutral"))
            return;
        else if(choice.contains("UPDATE")){
            //YOU IS GONNA NEED TO UPDATE.
            String[] parts = choice.split("UPDATE");
            String name = parts[0];
            String newName = parts[1];
            String newNumber = parts[2];
            contacts.remove(name);
            contacts.put(newName, newNumber);
            displayedContacts.remove(name);
            displayedContacts.add(newName);
            contactListAdapter.notifyDataSetChanged();
        }
        else{
            displayedContacts.remove(choice);
            contactListAdapter.notifyDataSetChanged();
        }
    }

    //User Clicks on a particular contact or a location
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        //Need to know if its a contact or a location
        //Toast.makeText(getBaseContext(),"same click listener", Toast.LENGTH_SHORT).show();

        String nameClicked = ((TextView)view).getText().toString();
        String phoneNumberClicked = contacts.get(nameClicked);

        if(phoneNumberClicked != null){
            ContactDisplayDialog cdd = new ContactDisplayDialog(nameClicked, phoneNumberClicked);
            cdd.show(getSupportFragmentManager(), "ContactDisplayDialog");
        }
        else{
            LatLng coordinatesClicked = locations.get(nameClicked);
            Intent mapIntent = new Intent(this, LocationActivity.class);
            mapIntent.putExtra("locationName", nameClicked);
            mapIntent.putExtra("latitude", coordinatesClicked.latitude);
            mapIntent.putExtra("longitude", coordinatesClicked.longitude);
            startActivity(mapIntent);
            finish();
        }


    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                //Launch Settings
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent1 = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent1);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
