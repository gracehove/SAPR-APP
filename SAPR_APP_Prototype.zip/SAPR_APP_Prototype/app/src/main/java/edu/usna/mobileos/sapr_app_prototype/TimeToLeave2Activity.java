package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import javax.net.ssl.HttpsURLConnection;

public class TimeToLeave2Activity extends AppCompatActivity implements MyDialogDateReturnInterface, MyDialogTimeReturnInterface, MyDialogSimpleReturnInterface {

    private AlarmManager alarmManager;

    public TextView sender;
    public TextView type;
    public TextView message;

    public long timeDelay = 0;

    Intent intent;

    private String senderName = "John Smith";
    private String messageContent = "You have a CDO muster in 15 minutes!";
    private String typeContent = "Text";

    private String requestTextURL = "https://us-central1-usna-sapr-app.cloudfunctions.net/textStatus";
    private String requestCallURL = "https://us-central1-usna-sapr-app.cloudfunctions.net/callUser";
    private URL textURL;
    private URL callURL;

    //public static final String ACCOUNT_SID = System.getenv("TWILIO_ACCOUNT_SID");
    //public static final String AUTH_TOKEN = System.getenv("TWILIO_AUTH_TOKEN");

    public TimeToLeave2Activity() throws MalformedURLException {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_to_leave2);

        sender = findViewById(R.id.sender);
        type = findViewById(R.id.type);
        message = findViewById(R.id.message);

        //Check to see if we just came from a settings update:
        intent = getIntent();

        String newSenderName = intent.getStringExtra("sender");
        String newMessageContent = intent.getStringExtra("message");
        String newTypeContent = intent.getStringExtra("type");

        if(newSenderName != null && newMessageContent != null && newTypeContent != null){
            senderName = newSenderName;
            messageContent = newMessageContent;
            typeContent = newTypeContent;
        }

        //Display relevant fields
        sender.setText(senderName);
        message.setText(messageContent);
        type.setText(typeContent);

        //initialize Alarm Manager
        alarmManager = (AlarmManager) getBaseContext()
                .getSystemService(Context.ALARM_SERVICE);

        //Initialize URLs with malformed URL Protection
        try {
            textURL = new URL(requestTextURL);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try {
            callURL = new URL(requestCallURL);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        if(senderName.equals("John Smith")) {
            //IMMEDIATELY LAUNCH EXPLANATION DIALOG if we still on default settings
            TTLIntroDialog dialog = new TTLIntroDialog();
            dialog.show(getSupportFragmentManager(), "TTLIntroDialog");
        }
    }

    //Back button allows settings updates.
    public void returnToSettings(View view) {
        Intent intent = new Intent(getBaseContext(), TimeToLeaveActivity.class);
        startActivity(intent);
        finish();
    }

    //Launch message sender right away.
    public void sendMessage(View view) throws IOException {
        send();
    }

    //Pick delay for message to be sent.
    public void ScheduleSendMessage(View view) {
        //Launch timer dialog
        myTimePickerDialog dialog7 = new myTimePickerDialog();
        dialog7.show(getSupportFragmentManager(), "TimePickerDialog");
    }


    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    //Initiation of options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    //OnClick of options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.main_menu:
                //Launch Main Menu
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.impaired_mode:
                //Launch Impaired Mode
                Intent intent2 = new Intent(this, ImpairedModeActivity.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.settings:
                //Launch Settings
                Intent intent1 = new Intent(this, SettingsActivity.class);
                startActivity(intent1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //We may need this later, in case user is picking a future time around 2359..
    @Override
    public void onDialogDateClick(Date date, long difference) {
        //The difference is the seconds until the selected day starts.. or seconds until MIDNIGHT

        //If the difference is negative, the selected day is today
        if (difference <= 0) {
            long timeDateDelay = 0;
        } else {
            long timeDateDelay = difference;
        }

        //Trouble shooting initiative
        String differences = String.valueOf(difference);
        Toast.makeText(getBaseContext(), differences, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDialogTimeClick(int hour, int minute) throws MalformedURLException, ParseException /*throws Exception*/{
        Boolean stillSending = true;

        //Get the current time: formatted as string
        String currentTime = String.valueOf(Calendar.getInstance().getTime());
        //"MMM dd, yyyy HH:mm:ss a"

        //Parse string to get pertinent fields
        String stringHour = currentTime.substring(11,13);
        String stringMinute = currentTime.substring(14,16);
        String stringSecond = currentTime.substring(17,19);

        //Convert to useable int
        int thisHour = Integer.valueOf(stringHour);
        int thisMinute = Integer.valueOf(stringMinute);
        int thisSecond = Integer.valueOf(stringSecond);

        //Calculate expected elapsed time in milliseconds
        long thisTime = (thisSecond) + (thisMinute * 60) + (thisHour * 3600);
        long pickedTime = (minute * 60) + (hour * 3600);

        long waitTime = (pickedTime - thisTime) * 1000;

        //Ensure user did not pick a past time
        if(waitTime < 0){
            Toast.makeText(getBaseContext(), "Must pick future time", Toast.LENGTH_LONG).show();
            stillSending = false;
        }

        //Set the global wait time to waitTime:
        if (stillSending){
            timeDelay = waitTime;
        }

        //Send the message
        send();
    }

    public void send() throws MalformedURLException {
        //Text or call?
        HashMap<String, String> parameters = new HashMap<String, String>();
        String fullMessage = "Hey this is " + senderName + ", " + messageContent;
        parameters.put("message", fullMessage);

        if(typeContent.equals("Text")) {

            //Get message content from user input:


            /** OLD MESSAGE SEND METHOD */

            /*
            //create implicit intent for ACTION_SENDTO
            final Intent intent2 = new Intent(Intent.ACTION_SENDTO);
            //set the number and message
            intent2.setData(Uri.parse("smsto:5554")); //5556 is the "phone number" of the second AVD
            intent2.putExtra("sms_body", fullMessage);

            //Intent handler required to ensure 7 second delay.
            Handler handler = new Handler();

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(intent2);
                }
            }, timeDelay); //variable second delay */

            /** NEW MESSAGE SEND METHOD */
            String _Query = textURL.getQuery();
            Toast.makeText(getBaseContext(), _Query, Toast.LENGTH_SHORT).show();
            Toast.makeText(getBaseContext(), "Text sent to ALEX'S IPHONE due to free trial status", Toast.LENGTH_SHORT).show();

        } else { //Place a phone call:

            //Intent handler required to ensure 7 second delay.
            Handler handler = new Handler();
            // Instantiate the RequestQueue.
            final RequestQueue queue = Volley.newRequestQueue(this);

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, requestCallURL, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Do nothing?
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //textView.setText("That didn't work!");
                        }
                    });

                    // Add the request to the RequestQueue.
                    queue.add(stringRequest);
                    Toast.makeText(getBaseContext(), "Call sent to ALEX'S IPHONE due to free trial status", Toast.LENGTH_SHORT).show();
                }
            }, timeDelay); //variable second delay */
        }
    }

    //Return yes/no from settings prompt
    @Override
    public void onDialogSimpleItemClick(String choice) {
        if(choice.equals("Positive")){
            //Customize settings in settings activity
            Intent intent = new Intent(getBaseContext(), TimeToLeaveActivity.class);
            startActivity(intent);
            finish();
        }
        //Otherwise keep default values.
    }
}

