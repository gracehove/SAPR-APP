package edu.usna.mobileos.sapr_app_prototype;

import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.Date;

public interface MyDialogTimeReturnInterface {

    public void onDialogTimeClick(int hour, int minute) throws MalformedURLException, ParseException;

}
