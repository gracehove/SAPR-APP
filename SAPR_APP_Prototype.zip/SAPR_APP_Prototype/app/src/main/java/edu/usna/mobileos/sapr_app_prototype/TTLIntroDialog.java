package edu.usna.mobileos.sapr_app_prototype;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;

public class TTLIntroDialog extends DialogFragment implements DialogInterface.OnClickListener {

    MyDialogSimpleReturnInterface myInterface; //custom listener is a class member

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        myInterface = (MyDialogSimpleReturnInterface) getActivity();
        //create an alert dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Time To Leave")
                .setMessage("If you want to get out of an uncomfortable situation, Time to Leave allows you to send yourself a fake message or excuse to leave. Would you like to customize settings?")
                .setPositiveButton("YES", this)
                .setNegativeButton("NO", this)
                .setCancelable(false);

        //call create to build the dialog and return it
        return builder.create();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int i) {
        String buttonName = "";
        //id identifies the button clicked

        switch (i) {
            case Dialog.BUTTON_NEGATIVE:
                buttonName = "Negative";
                break;
            case Dialog.BUTTON_POSITIVE:
                buttonName = "Positive";
                break;
        }

        myInterface.onDialogSimpleItemClick(buttonName);
    }
}
